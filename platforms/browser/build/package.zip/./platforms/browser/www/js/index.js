
var app = {
    localNote: null,
    init: function() {
        try{
            document.addEventListener('deviceready', this.onDeviceReady.bind(this), false);
        }catch(e){
            document.addEventListener('DOMContentLoaded', this.onDeviceReady.bind(this), false);
            console.log('failed to find deviceready');
        }
    },
    onDeviceReady: function() {
        //set up event listeners and default variable values
        window.addEventListener('push', app.pageChanged);
        //cordova.plugins.notification.local
        app.localNote = cordova.plugins.notification.local;
        app.localNote.on("click", function (notification) {
            
        });
        //show the list when loading
        app.showList();
    },
    pageChanged: function(){
        //user has clicked a link in the tab menu and new page loaded
        //check to see which page and then call the appropriate function
        
        if(document.getElementById('page-notify')){
            app.showList();
        }
        else{
            
            let button = document.querySelector('#btnAdd');
            button.addEventListener("click", app.saveNew);
            console.log("Button is clicked and function saveNew is called");
            
            let notificationTime = new Date();
            notificationTime.setMinutes(notificationTime.getMinutes() + 2);
            console.log(notificationTime);
            
            let time = document.querySelector('#time');
            time.value = notificationTime.toString();
            console.log("Time is " + time);
            
            }
    },
    showList: function(){
        let list = document.querySelector('#list-notify');
    },
    saveNew: function(ev){
        ev.preventDefault();
        //create a new notification with the details from the form
        
    }
};

app.init();